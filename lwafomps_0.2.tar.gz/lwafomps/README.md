# lwafomps
Calculate Cumulative distribution of Multivariate Normal Distribution using randomized Quasi-Monte-Calro Method. Low WAFOM Point Set is used for QMC.

Caution: Currently, this project is very experimental.
