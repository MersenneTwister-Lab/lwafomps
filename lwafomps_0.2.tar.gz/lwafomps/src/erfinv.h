#pragma once
#ifndef ERFINV_H
#define ERFINV_H

namespace ErrorFunction {
    double erfinv(double x);
}
#endif // ERFINV_H
